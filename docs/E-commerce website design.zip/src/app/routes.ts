import { createBrowserRouter } from 'react-router';
import { UserLayout } from './components/layout/UserLayout';
import { AdminLayout } from './components/layout/AdminLayout';
import { HomePage } from './components/user/HomePage';
import { ProductsPage } from './components/user/ProductsPage';
import { ProductDetailPage } from './components/user/ProductDetailPage';
import { CartPage } from './components/user/CartPage';
import { CheckoutPage } from './components/user/CheckoutPage';
import { LoginPage } from './components/user/LoginPage';
import { RegisterPage } from './components/user/RegisterPage';
import { AccountPage } from './components/user/AccountPage';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminProducts } from './components/admin/AdminProducts';
import { AdminOrders } from './components/admin/AdminOrders';
import { AdminCustomers } from './components/admin/AdminCustomers';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: UserLayout,
    children: [
      { index: true, Component: HomePage },
      { path: 'products', Component: ProductsPage },
      { path: 'products/:id', Component: ProductDetailPage },
      { path: 'cart', Component: CartPage },
      { path: 'checkout', Component: CheckoutPage },
      { path: 'account', Component: AccountPage },
    ],
  },
  {
    path: '/login',
    Component: LoginPage,
  },
  {
    path: '/register',
    Component: RegisterPage,
  },
  {
    path: '/admin',
    Component: AdminLayout,
    children: [
      { index: true, Component: AdminDashboard },
      { path: 'products', Component: AdminProducts },
      { path: 'orders', Component: AdminOrders },
      { path: 'customers', Component: AdminCustomers },
    ],
  },
]);
