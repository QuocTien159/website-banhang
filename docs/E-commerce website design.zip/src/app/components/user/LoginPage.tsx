import { useState } from 'react';
import { Link, useNavigate, useLocation } from 'react-router';
import { Eye, EyeOff, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../store/AppContext';
import { Button } from '../ui/button';
import { toast } from 'sonner';

export function LoginPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const from = (location.state as { from?: string })?.from || '/';

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    await new Promise(r => setTimeout(r, 500));
    const success = login(email, password);
    setLoading(false);
    if (success) {
      toast.success('Đăng nhập thành công!');
      navigate(email === 'admin@sportzone.vn' ? '/admin' : from, { replace: true });
    } else {
      setError('Email hoặc mật khẩu không đúng. Thử lại với tài khoản demo bên dưới.');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left - Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8">
            <ArrowLeft className="w-4 h-4" /> Về trang chủ
          </Link>

          {/* Logo */}
          <div className="flex items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#ea5c21' }}>
              <span className="text-white text-xs font-bold">SZ</span>
            </div>
            <span className="text-lg" style={{ fontWeight: 700 }}>
              Sport<span style={{ color: '#ea5c21' }}>Zone</span>
            </span>
          </div>

          <h2 className="mb-1">Đăng nhập</h2>
          <p className="text-sm text-muted-foreground mb-6">Chào mừng bạn quay lại!</p>

          {/* Demo credentials */}
          <div className="mb-6 p-3 bg-blue-50 rounded-lg border border-blue-100">
            <p className="text-xs font-medium text-blue-700 mb-1">Tài khoản demo:</p>
            <div className="text-xs text-blue-600 space-y-0.5">
              <p>👤 User: <strong>user@example.com</strong> / <strong>user123</strong></p>
              <p>🔑 Admin: <strong>admin@sportzone.vn</strong> / <strong>admin123</strong></p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-sm font-medium">Email</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                placeholder="example@email.com"
                required
              />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Mật khẩu</label>
                <a href="#" className="text-xs hover:underline" style={{ color: '#ea5c21' }}>Quên mật khẩu?</a>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2 pr-10 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-xs text-red-600">{error}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full text-white"
              disabled={loading}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              {loading ? 'Đang đăng nhập...' : 'Đăng nhập'}
            </Button>
          </form>

          <p className="text-sm text-center text-muted-foreground mt-6">
            Chưa có tài khoản?{' '}
            <Link to="/register" className="hover:underline" style={{ color: '#ea5c21' }}>
              Đăng ký ngay
            </Link>
          </p>
        </div>
      </div>

      {/* Right - Illustration */}
      <div className="hidden lg:flex flex-1 items-center justify-center" style={{ background: 'linear-gradient(135deg, #030213 0%, #1a1a3e 100%)' }}>
        <div className="text-center text-white p-12">
          <div className="text-8xl mb-8">🏆</div>
          <h3 className="text-white mb-3" style={{ fontSize: '1.5rem' }}>SportZone</h3>
          <p className="text-gray-400 text-sm max-w-xs">
            Hơn 500+ sản phẩm thể thao chính hãng. Giao hàng nhanh toàn quốc. Bảo hành uy tín.
          </p>
          <div className="grid grid-cols-3 gap-4 mt-8">
            {[
              { label: 'Sản phẩm', value: '500+' },
              { label: 'Khách hàng', value: '10K+' },
              { label: 'Đánh giá 5⭐', value: '98%' },
            ].map(stat => (
              <div key={stat.label} className="bg-white/10 rounded-xl p-3">
                <p className="text-xl font-bold" style={{ color: '#ea5c21' }}>{stat.value}</p>
                <p className="text-xs text-gray-400">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
