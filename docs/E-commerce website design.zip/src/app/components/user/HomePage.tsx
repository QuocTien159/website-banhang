import { Link, useNavigate } from 'react-router';
import { ArrowRight, Star, Shield, Truck, RefreshCw, Headphones } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { CATEGORIES, HERO_IMAGE, formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner';

export function HomePage() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const featuredProducts = state.products.filter(p => p.featured);

  const handleAddToCart = (product: typeof state.products[0]) => {
    dispatch({ type: 'ADD_TO_CART', payload: product });
    toast.success(`Đã thêm "${product.name}" vào giỏ hàng`);
  };

  return (
    <div>
      {/* Hero */}
      <section className="relative h-[500px] md:h-[600px] overflow-hidden">
        <ImageWithFallback
          src={HERO_IMAGE}
          alt="SportZone Hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: 'linear-gradient(to right, rgba(3,2,19,0.85) 0%, rgba(3,2,19,0.4) 60%, transparent 100%)' }} />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-7xl mx-auto px-4 w-full">
            <div className="max-w-lg">
              <span className="inline-block px-3 py-1 rounded-full text-xs text-white mb-4" style={{ backgroundColor: '#ea5c21' }}>
                🔥 SALE UP TO 30%
              </span>
              <h1 className="text-white mb-4" style={{ fontSize: '2.5rem', lineHeight: '1.2', fontWeight: 700 }}>
                Dụng Cụ Thể Thao<br />
                <span style={{ color: '#ea5c21' }}>Chính Hãng</span> Tốt Nhất
              </h1>
              <p className="text-gray-300 mb-8" style={{ fontSize: '1rem' }}>
                Hơn 500+ sản phẩm từ các thương hiệu hàng đầu. Giao hàng nhanh toàn quốc. Bảo hành chính hãng.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={() => navigate('/products')}
                  className="gap-2"
                  style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
                >
                  Mua ngay <ArrowRight className="w-4 h-4" />
                </Button>
                <Button
                  variant="outline"
                  onClick={() => navigate('/products?category=Gym+%26+Fitness')}
                  className="border-white text-white hover:bg-white hover:text-black"
                >
                  Gym & Fitness
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Trust badges */}
      <section className="bg-[#030213] text-white py-4">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { icon: Truck, label: 'Miễn phí vận chuyển', sub: 'Đơn từ 500.000đ' },
              { icon: Shield, label: 'Bảo hành chính hãng', sub: 'Lên đến 24 tháng' },
              { icon: RefreshCw, label: 'Đổi trả dễ dàng', sub: 'Trong vòng 30 ngày' },
              { icon: Headphones, label: 'Hỗ trợ 24/7', sub: '1800 1234 (miễn phí)' },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="flex items-center gap-3 py-1">
                <div className="w-9 h-9 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: 'rgba(234,92,33,0.2)' }}>
                  <Icon className="w-4 h-4" style={{ color: '#ea5c21' }} />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{label}</p>
                  <p className="text-xs text-gray-400">{sub}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-6">
          <h2>Danh mục sản phẩm</h2>
          <Link to="/products" className="text-sm flex items-center gap-1 hover:underline" style={{ color: '#ea5c21' }}>
            Xem tất cả <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.name}
              to={`/products?category=${encodeURIComponent(cat.name)}`}
              className="group flex flex-col items-center gap-2 p-4 bg-white rounded-xl border border-border hover:border-orange-400 hover:shadow-md transition-all"
            >
              <span className="text-2xl">{cat.emoji}</span>
              <span className="text-xs text-center text-muted-foreground group-hover:text-orange-600 transition-colors leading-tight">
                {cat.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 pb-12">
        <div className="flex items-center justify-between mb-6">
          <h2>Sản phẩm nổi bật</h2>
          <Link to="/products" className="text-sm flex items-center gap-1 hover:underline" style={{ color: '#ea5c21' }}>
            Xem tất cả <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {featuredProducts.map(product => (
            <div key={product.id} className="bg-white rounded-xl border border-border overflow-hidden group hover:shadow-lg transition-shadow">
              <div
                className="relative aspect-square overflow-hidden cursor-pointer bg-gray-50"
                onClick={() => navigate(`/products/${product.id}`)}
              >
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                {product.originalPrice && (
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md text-xs text-white" style={{ backgroundColor: '#ea5c21' }}>
                    -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                  </span>
                )}
              </div>
              <div className="p-3">
                <p className="text-xs text-muted-foreground mb-1">{product.category}</p>
                <h4
                  className="cursor-pointer hover:text-orange-600 transition-colors line-clamp-2 mb-2"
                  onClick={() => navigate(`/products/${product.id}`)}
                >
                  {product.name}
                </h4>
                <div className="flex items-center gap-1 mb-2">
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                  <span className="text-xs text-muted-foreground">{product.rating} ({product.reviewCount})</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-sm font-semibold" style={{ color: '#ea5c21' }}>{formatPrice(product.price)}</span>
                    {product.originalPrice && (
                      <span className="text-xs text-muted-foreground line-through ml-1">{formatPrice(product.originalPrice)}</span>
                    )}
                  </div>
                </div>
                <Button
                  size="sm"
                  className="w-full mt-2 text-xs"
                  style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
                  onClick={() => handleAddToCart(product)}
                >
                  Thêm vào giỏ
                </Button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Promo Banner */}
      <section className="max-w-7xl mx-auto px-4 pb-12">
        <div
          className="rounded-2xl overflow-hidden relative h-48 flex items-center"
          style={{ background: 'linear-gradient(135deg, #030213 0%, #1a1a3e 50%, #2d1b00 100%)' }}
        >
          <div className="px-8 md:px-12 relative z-10">
            <div className="inline-block px-3 py-1 rounded-full text-xs text-white mb-3" style={{ backgroundColor: '#ea5c21' }}>
              ƯU ĐÃI ĐẶC BIỆT
            </div>
            <h3 className="text-white mb-2" style={{ fontSize: '1.4rem' }}>
              Giảm <span style={{ color: '#ea5c21' }}>20%</span> cho đơn hàng đầu tiên
            </h3>
            <p className="text-gray-400 text-sm mb-4">Nhập mã <strong className="text-white">SPORT20</strong> khi thanh toán</p>
            <Button
              size="sm"
              onClick={() => navigate('/products')}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              Mua ngay
            </Button>
          </div>
          <div className="absolute right-0 bottom-0 text-[120px] opacity-10 select-none pointer-events-none pr-8">
            🏆
          </div>
        </div>
      </section>

      {/* All Products Preview */}
      <section className="max-w-7xl mx-auto px-4 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h2>Sản phẩm mới nhất</h2>
          <Link to="/products" className="text-sm flex items-center gap-1 hover:underline" style={{ color: '#ea5c21' }}>
            Xem tất cả <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {state.products.slice(0, 6).map(product => (
            <Link
              key={product.id}
              to={`/products/${product.id}`}
              className="group bg-white rounded-xl border border-border overflow-hidden hover:shadow-md transition-shadow"
            >
              <div className="aspect-square overflow-hidden bg-gray-50">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-2">
                <p className="text-xs truncate text-muted-foreground">{product.name}</p>
                <p className="text-xs font-semibold mt-0.5" style={{ color: '#ea5c21' }}>{formatPrice(product.price)}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
