import { useNavigate } from 'react-router';
import { Package, User as UserIcon, MapPin, Phone, Calendar, Clock } from 'lucide-react';
import { useAuth, useApp } from '../../store/AppContext';
import { formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';

const STATUS_MAP: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
  pending: { label: 'Chờ xác nhận', variant: 'secondary' },
  confirmed: { label: 'Đã xác nhận', variant: 'default' },
  shipping: { label: 'Đang giao', variant: 'default' },
  delivered: { label: 'Đã giao', variant: 'default' },
  cancelled: { label: 'Đã hủy', variant: 'destructive' },
};

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  confirmed: 'bg-blue-100 text-blue-700',
  shipping: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

export function AccountPage() {
  const { user, isAuthenticated } = useAuth();
  const { state } = useApp();
  const navigate = useNavigate();

  if (!isAuthenticated || !user) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="max-w-sm mx-auto">
          <div className="text-5xl mb-4">🔐</div>
          <h2 className="mb-2">Đăng nhập để xem đơn hàng</h2>
          <p className="text-muted-foreground text-sm mb-6">Bạn cần đăng nhập để xem lịch sử đơn hàng và thông tin tài khoản</p>
          <div className="flex gap-3 justify-center">
            <Button onClick={() => navigate('/login')} style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}>
              Đăng nhập
            </Button>
            <Button variant="outline" onClick={() => navigate('/register')}>Đăng ký</Button>
          </div>
        </div>
      </div>
    );
  }

  const myOrders = user.role === 'admin'
    ? state.orders
    : state.orders.filter(o => o.userId === user.id || o.userId === 'u_demo' || o.shippingInfo?.name === user.name);

  const formatDate = (iso: string) => {
    const d = new Date(iso);
    return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="mb-6">Tài khoản của tôi</h2>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Profile */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-border p-5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-14 h-14 rounded-full flex items-center justify-center text-white text-xl font-bold" style={{ backgroundColor: '#ea5c21' }}>
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h4>{user.name}</h4>
                <span className={`text-xs px-2 py-0.5 rounded-full ${user.role === 'admin' ? 'bg-orange-100 text-orange-700' : 'bg-gray-100 text-gray-600'}`}>
                  {user.role === 'admin' ? 'Quản trị viên' : 'Thành viên'}
                </span>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <UserIcon className="w-3.5 h-3.5" />
                <span>{user.email}</span>
              </div>
              {user.phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-3.5 h-3.5" />
                  <span>{user.phone}</span>
                </div>
              )}
              {user.address && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5" />
                  <span className="line-clamp-2">{user.address}</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Calendar className="w-3.5 h-3.5" />
                <span>Tham gia: {user.joinDate}</span>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: 'Đơn hàng', value: myOrders.length, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: 'Đã giao', value: myOrders.filter(o => o.status === 'delivered').length, color: 'text-green-600', bg: 'bg-green-50' },
            ].map(stat => (
              <div key={stat.label} className={`${stat.bg} rounded-xl p-4 text-center`}>
                <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>

          {user.role === 'admin' && (
            <Button
              className="w-full text-white"
              onClick={() => navigate('/admin')}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              Vào trang quản trị
            </Button>
          )}
        </div>

        {/* Orders */}
        <div className="md:col-span-2">
          <div className="bg-white rounded-xl border border-border">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h4 className="flex items-center gap-2">
                <Package className="w-4 h-4" style={{ color: '#ea5c21' }} />
                Lịch sử đơn hàng
              </h4>
            </div>
            {myOrders.length === 0 ? (
              <div className="p-12 text-center">
                <span className="text-4xl mb-3 block">📦</span>
                <p className="text-muted-foreground text-sm">Bạn chưa có đơn hàng nào</p>
                <Button
                  className="mt-4"
                  size="sm"
                  onClick={() => navigate('/products')}
                  style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
                >
                  Mua sắm ngay
                </Button>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {myOrders.map(order => (
                  <div key={order.id} className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <p className="text-sm font-medium">{order.id}</p>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mt-0.5">
                          <Clock className="w-3 h-3" />
                          {formatDate(order.createdAt)}
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[order.status]}`}>
                        {STATUS_MAP[order.status]?.label}
                      </span>
                    </div>
                    <div className="text-xs text-muted-foreground mb-2">
                      {order.items.map(item => `${item.product.name} x${item.quantity}`).join(', ')}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">
                        {order.shippingInfo.paymentMethod === 'cod' ? '💵 COD' : '🏦 Chuyển khoản'}
                      </div>
                      <span className="text-sm font-semibold" style={{ color: '#ea5c21' }}>
                        {formatPrice(order.total)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
