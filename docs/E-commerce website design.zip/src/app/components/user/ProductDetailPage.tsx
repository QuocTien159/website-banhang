import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router';
import { Star, ShoppingCart, ArrowLeft, Plus, Minus, Shield, Truck, RefreshCw, Share2 } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner';

const MOCK_REVIEWS = [
  { id: 1, name: 'Nguyễn Văn A', rating: 5, date: '15/04/2025', comment: 'Sản phẩm rất tốt, đúng mô tả. Giao hàng nhanh, đóng gói cẩn thận. Sẽ ủng hộ shop lần sau!' },
  { id: 2, name: 'Trần Thị B', rating: 4, date: '22/04/2025', comment: 'Chất lượng ổn, giá cả hợp lý. Chỉ tiếc là giao hơi chậm một chút nhưng nhìn chung hài lòng.' },
  { id: 3, name: 'Lê Minh C', rating: 5, date: '05/05/2025', comment: 'Tuyệt vời! Đúng chất lượng như mô tả, dùng được một tuần vẫn ổn định. Recommend ngay!' },
];

export function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  const [quantity, setQuantity] = useState(1);

  const product = state.products.find(p => p.id === id);
  const related = state.products.filter(p => p.category === product?.category && p.id !== id).slice(0, 4);

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <span className="text-6xl mb-4 block">😞</span>
        <h2>Không tìm thấy sản phẩm</h2>
        <Button className="mt-4" onClick={() => navigate('/products')} style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}>
          Quay về cửa hàng
        </Button>
      </div>
    );
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      dispatch({ type: 'ADD_TO_CART', payload: product });
    }
    toast.success(`Đã thêm ${quantity} "${product.name}" vào giỏ hàng`);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/cart');
  };

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <Link to="/" className="hover:text-foreground">Trang chủ</Link>
        <span>/</span>
        <Link to="/products" className="hover:text-foreground">Sản phẩm</Link>
        <span>/</span>
        <Link to={`/products?category=${encodeURIComponent(product.category)}`} className="hover:text-foreground">{product.category}</Link>
        <span>/</span>
        <span className="text-foreground truncate max-w-xs">{product.name}</span>
      </nav>

      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Image */}
        <div className="space-y-3">
          <div className="aspect-square rounded-2xl overflow-hidden bg-gray-50 border border-border">
            <ImageWithFallback
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Info */}
        <div>
          <div className="flex items-start justify-between gap-4 mb-2">
            <div>
              <span className="inline-block px-2 py-0.5 rounded text-xs text-orange-700 bg-orange-100 mb-2">{product.category}</span>
              <h1 style={{ fontSize: '1.5rem' }}>{product.name}</h1>
            </div>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-3 mb-4">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`w-4 h-4 ${i < Math.floor(product.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
              ))}
              <span className="text-sm text-muted-foreground ml-1">{product.rating}</span>
            </div>
            <span className="text-sm text-muted-foreground">({product.reviewCount} đánh giá)</span>
            <span className="text-sm text-muted-foreground">·</span>
            <span className="text-sm text-muted-foreground">Đã bán {product.sold}</span>
          </div>

          {/* Price */}
          <div className="flex items-end gap-3 mb-4 p-4 bg-orange-50 rounded-xl">
            <span className="text-3xl font-bold" style={{ color: '#ea5c21' }}>{formatPrice(product.price)}</span>
            {product.originalPrice && (
              <>
                <span className="text-lg text-muted-foreground line-through">{formatPrice(product.originalPrice)}</span>
                <span className="px-2 py-0.5 rounded text-sm text-white" style={{ backgroundColor: '#ea5c21' }}>
                  -{discount}%
                </span>
              </>
            )}
          </div>

          {/* Stock */}
          <div className="flex items-center gap-2 mb-4">
            <div className={`w-2 h-2 rounded-full ${product.stock > 10 ? 'bg-green-500' : product.stock > 0 ? 'bg-yellow-500' : 'bg-red-500'}`} />
            <span className="text-sm">
              {product.stock > 10 ? `Còn hàng (${product.stock} sản phẩm)` : product.stock > 0 ? `Còn ${product.stock} sản phẩm` : 'Hết hàng'}
            </span>
          </div>

          {/* Quantity */}
          <div className="flex items-center gap-4 mb-6">
            <span className="text-sm font-medium">Số lượng:</span>
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <button
                onClick={() => setQuantity(q => Math.max(1, q - 1))}
                className="w-9 h-9 flex items-center justify-center hover:bg-accent transition-colors"
              >
                <Minus className="w-3 h-3" />
              </button>
              <span className="w-12 text-center text-sm font-medium">{quantity}</span>
              <button
                onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                className="w-9 h-9 flex items-center justify-center hover:bg-accent transition-colors"
                disabled={quantity >= product.stock}
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 mb-6">
            <Button
              className="flex-1 gap-2"
              variant="outline"
              onClick={handleAddToCart}
              disabled={product.stock === 0}
            >
              <ShoppingCart className="w-4 h-4" />
              Thêm vào giỏ
            </Button>
            <Button
              className="flex-1 gap-2 text-white"
              onClick={handleBuyNow}
              disabled={product.stock === 0}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              Mua ngay
            </Button>
          </div>

          {/* Trust */}
          <div className="grid grid-cols-3 gap-3 p-4 bg-gray-50 rounded-xl">
            {[
              { icon: Truck, label: 'Miễn phí vận chuyển', sub: 'Đơn từ 500.000đ' },
              { icon: Shield, label: 'Bảo hành chính hãng', sub: product.specs.find(s => s.label === 'Bảo hành')?.value || '12 tháng' },
              { icon: RefreshCw, label: 'Đổi trả 30 ngày', sub: 'Nếu lỗi sản phẩm' },
            ].map(({ icon: Icon, label, sub }) => (
              <div key={label} className="text-center">
                <div className="w-8 h-8 rounded-full flex items-center justify-center mx-auto mb-1" style={{ backgroundColor: 'rgba(234,92,33,0.1)' }}>
                  <Icon className="w-4 h-4" style={{ color: '#ea5c21' }} />
                </div>
                <p className="text-xs font-medium">{label}</p>
                <p className="text-xs text-muted-foreground">{sub}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="description" className="mb-12">
        <TabsList>
          <TabsTrigger value="description">Mô tả sản phẩm</TabsTrigger>
          <TabsTrigger value="specs">Thông số kỹ thuật</TabsTrigger>
          <TabsTrigger value="reviews">Đánh giá ({product.reviewCount})</TabsTrigger>
        </TabsList>
        <TabsContent value="description" className="mt-4 p-4 bg-white rounded-xl border border-border">
          <p className="text-sm leading-relaxed text-muted-foreground">{product.description}</p>
        </TabsContent>
        <TabsContent value="specs" className="mt-4 p-4 bg-white rounded-xl border border-border">
          <div className="space-y-0">
            {product.specs.map((spec, i) => (
              <div key={i} className={`flex py-3 ${i < product.specs.length - 1 ? 'border-b border-border' : ''}`}>
                <span className="w-40 text-sm text-muted-foreground shrink-0">{spec.label}</span>
                <span className="text-sm font-medium">{spec.value}</span>
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="reviews" className="mt-4 space-y-4">
          {MOCK_REVIEWS.map(review => (
            <div key={review.id} className="p-4 bg-white rounded-xl border border-border">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-sm font-medium">{review.name}</p>
                  <div className="flex items-center gap-1 mt-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`w-3 h-3 ${i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
                    ))}
                  </div>
                </div>
                <span className="text-xs text-muted-foreground">{review.date}</span>
              </div>
              <p className="text-sm text-muted-foreground">{review.comment}</p>
            </div>
          ))}
        </TabsContent>
      </Tabs>

      {/* Related products */}
      {related.length > 0 && (
        <section>
          <h2 className="mb-6">Sản phẩm liên quan</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {related.map(p => (
              <div
                key={p.id}
                className="bg-white rounded-xl border border-border overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => navigate(`/products/${p.id}`)}
              >
                <div className="aspect-square overflow-hidden bg-gray-50">
                  <ImageWithFallback src={p.image} alt={p.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" />
                </div>
                <div className="p-3">
                  <p className="text-sm line-clamp-2 mb-1">{p.name}</p>
                  <span className="text-sm font-semibold" style={{ color: '#ea5c21' }}>{formatPrice(p.price)}</span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
