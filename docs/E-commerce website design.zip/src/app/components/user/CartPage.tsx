import { Link, useNavigate } from 'react-router';
import { Trash2, Plus, Minus, ShoppingCart, ArrowRight, Tag } from 'lucide-react';
import { useCart } from '../../store/AppContext';
import { formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function CartPage() {
  const { cart, totalItems, subtotal, shipping, total, dispatch } = useCart();
  const navigate = useNavigate();

  const handleQuantityChange = (productId: string, newQty: number) => {
    if (newQty <= 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: productId });
    } else {
      dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { productId, quantity: newQty } });
    }
  };

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <div className="max-w-sm mx-auto">
          <div className="w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6 bg-orange-50">
            <ShoppingCart className="w-10 h-10" style={{ color: '#ea5c21' }} />
          </div>
          <h2 className="mb-2">Giỏ hàng trống</h2>
          <p className="text-muted-foreground text-sm mb-6">Bạn chưa có sản phẩm nào trong giỏ hàng</p>
          <Button
            onClick={() => navigate('/products')}
            style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
          >
            Tiếp tục mua sắm
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h2 className="mb-6">Giỏ hàng ({totalItems} sản phẩm)</h2>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-3">
          {cart.map(item => (
            <div key={item.product.id} className="bg-white rounded-xl border border-border p-4 flex gap-4">
              <div
                className="w-20 h-20 rounded-lg overflow-hidden bg-gray-50 shrink-0 cursor-pointer"
                onClick={() => navigate(`/products/${item.product.id}`)}
              >
                <ImageWithFallback
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-xs text-muted-foreground">{item.product.category}</span>
                    <h4
                      className="text-sm cursor-pointer hover:text-orange-600 transition-colors"
                      onClick={() => navigate(`/products/${item.product.id}`)}
                    >
                      {item.product.name}
                    </h4>
                  </div>
                  <button
                    onClick={() => dispatch({ type: 'REMOVE_FROM_CART', payload: item.product.id })}
                    className="text-muted-foreground hover:text-red-500 transition-colors shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center border border-border rounded-lg overflow-hidden">
                    <button
                      onClick={() => handleQuantityChange(item.product.id, item.quantity - 1)}
                      className="w-8 h-8 flex items-center justify-center hover:bg-accent transition-colors"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-10 text-center text-sm">{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item.product.id, item.quantity + 1)}
                      className="w-8 h-8 flex items-center justify-center hover:bg-accent transition-colors"
                      disabled={item.quantity >= item.product.stock}
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <span className="text-sm font-semibold" style={{ color: '#ea5c21' }}>
                    {formatPrice(item.product.price * item.quantity)}
                  </span>
                </div>
              </div>
            </div>
          ))}

          <div className="flex justify-between items-center pt-2">
            <button
              onClick={() => dispatch({ type: 'CLEAR_CART' })}
              className="text-sm text-red-500 hover:underline"
            >
              Xóa tất cả
            </button>
            <Link to="/products" className="text-sm hover:underline" style={{ color: '#ea5c21' }}>
              ← Tiếp tục mua sắm
            </Link>
          </div>
        </div>

        {/* Order Summary */}
        <div className="space-y-4">
          {/* Voucher */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <Tag className="w-4 h-4" style={{ color: '#ea5c21' }} />
              Mã giảm giá
            </h4>
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Nhập mã voucher"
                className="flex-1 text-sm px-3 py-1.5 border border-border rounded-lg focus:outline-none focus:border-orange-400"
              />
              <Button size="sm" variant="outline">Áp dụng</Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">Thử: SPORT20</p>
          </div>

          {/* Summary */}
          <div className="bg-white rounded-xl border border-border p-4">
            <h4 className="text-sm font-semibold mb-4">Tóm tắt đơn hàng</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Tạm tính ({totalItems} sản phẩm)</span>
                <span>{formatPrice(subtotal)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Phí vận chuyển</span>
                <span className={shipping === 0 ? 'text-green-600' : ''}>{shipping === 0 ? 'Miễn phí' : formatPrice(shipping)}</span>
              </div>
              {shipping === 0 && (
                <p className="text-xs text-green-600">🎉 Bạn được miễn phí vận chuyển!</p>
              )}
              {shipping > 0 && (
                <p className="text-xs text-muted-foreground">
                  Mua thêm {formatPrice(500000 - subtotal)} để được miễn phí vận chuyển
                </p>
              )}
              <div className="border-t border-border pt-2 flex justify-between">
                <span className="font-semibold">Tổng cộng</span>
                <span className="font-semibold text-lg" style={{ color: '#ea5c21' }}>{formatPrice(total)}</span>
              </div>
            </div>
            <Button
              className="w-full mt-4 gap-2 text-white"
              onClick={() => navigate('/checkout')}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              Tiến hành thanh toán <ArrowRight className="w-4 h-4" />
            </Button>
          </div>

          {/* Shipping info */}
          <div className="bg-orange-50 rounded-xl p-4">
            <p className="text-sm text-orange-800">
              🚚 <strong>Miễn phí vận chuyển</strong> toàn quốc cho đơn từ 500.000đ
            </p>
            <p className="text-xs text-orange-600 mt-1">Giao hàng trong 1-3 ngày làm việc</p>
          </div>
        </div>
      </div>
    </div>
  );
}
