import { useState, useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router';
import { Star, SlidersHorizontal, X, ShoppingCart } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { CATEGORIES, Category, formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner';

type SortOption = 'newest' | 'price-asc' | 'price-desc' | 'rating' | 'sold';

export function ProductsPage() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [showFilters, setShowFilters] = useState(false);

  const currentCategory = searchParams.get('category') as Category | null;
  const searchQuery = searchParams.get('q') || '';
  const [sortBy, setSortBy] = useState<SortOption>('newest');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 2000000]);
  const [minRating, setMinRating] = useState(0);

  const filteredProducts = useMemo(() => {
    let result = [...state.products];
    if (currentCategory) result = result.filter(p => p.category === currentCategory);
    if (searchQuery) result = result.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()));
    result = result.filter(p => p.price >= priceRange[0] && p.price <= priceRange[1]);
    if (minRating > 0) result = result.filter(p => p.rating >= minRating);
    switch (sortBy) {
      case 'price-asc': result.sort((a, b) => a.price - b.price); break;
      case 'price-desc': result.sort((a, b) => b.price - a.price); break;
      case 'rating': result.sort((a, b) => b.rating - a.rating); break;
      case 'sold': result.sort((a, b) => b.sold - a.sold); break;
    }
    return result;
  }, [state.products, currentCategory, searchQuery, priceRange, minRating, sortBy]);

  const handleCategoryChange = (cat: Category | null) => {
    const params = new URLSearchParams(searchParams);
    if (cat) params.set('category', cat);
    else params.delete('category');
    setSearchParams(params);
  };

  const handleAddToCart = (product: typeof state.products[0], e: React.MouseEvent) => {
    e.stopPropagation();
    dispatch({ type: 'ADD_TO_CART', payload: product });
    toast.success(`Đã thêm "${product.name}" vào giỏ hàng`);
  };

  const clearFilters = () => {
    setSearchParams({});
    setPriceRange([0, 2000000]);
    setMinRating(0);
  };

  const hasActiveFilters = currentCategory || searchQuery || priceRange[0] > 0 || priceRange[1] < 2000000 || minRating > 0;

  const FilterPanel = () => (
    <div className="space-y-6">
      {/* Categories */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Danh mục</h4>
        <div className="space-y-1">
          <button
            onClick={() => handleCategoryChange(null)}
            className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${!currentCategory ? 'bg-orange-50 text-orange-600 font-medium' : 'text-muted-foreground hover:bg-accent'}`}
          >
            Tất cả ({state.products.length})
          </button>
          {CATEGORIES.map(cat => {
            const count = state.products.filter(p => p.category === cat.name).length;
            return (
              <button
                key={cat.name}
                onClick={() => handleCategoryChange(cat.name)}
                className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors flex items-center justify-between ${currentCategory === cat.name ? 'bg-orange-50 text-orange-600 font-medium' : 'text-muted-foreground hover:bg-accent'}`}
              >
                <span>{cat.emoji} {cat.name}</span>
                <span className="text-xs">{count}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Price Range */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Khoảng giá</h4>
        <div className="space-y-2">
          {[
            { label: 'Tất cả', min: 0, max: 2000000 },
            { label: 'Dưới 200.000đ', min: 0, max: 200000 },
            { label: '200.000đ - 500.000đ', min: 200000, max: 500000 },
            { label: '500.000đ - 1.000.000đ', min: 500000, max: 1000000 },
            { label: 'Trên 1.000.000đ', min: 1000000, max: 2000000 },
          ].map(range => (
            <button
              key={range.label}
              onClick={() => setPriceRange([range.min, range.max])}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors ${priceRange[0] === range.min && priceRange[1] === range.max ? 'bg-orange-50 text-orange-600 font-medium' : 'text-muted-foreground hover:bg-accent'}`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* Rating */}
      <div>
        <h4 className="text-sm font-semibold mb-3">Đánh giá</h4>
        <div className="space-y-1">
          {[0, 4, 4.5].map(rating => (
            <button
              key={rating}
              onClick={() => setMinRating(rating)}
              className={`w-full text-left px-3 py-1.5 rounded-lg text-sm transition-colors flex items-center gap-1.5 ${minRating === rating ? 'bg-orange-50 text-orange-600 font-medium' : 'text-muted-foreground hover:bg-accent'}`}
            >
              {rating === 0 ? (
                'Tất cả'
              ) : (
                <>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`w-3 h-3 ${i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} />
                  ))}
                  <span>từ {rating}+</span>
                </>
              )}
            </button>
          ))}
        </div>
      </div>

      {hasActiveFilters && (
        <button onClick={clearFilters} className="w-full px-3 py-2 rounded-lg text-sm text-red-500 border border-red-200 hover:bg-red-50 transition-colors flex items-center justify-center gap-2">
          <X className="w-3 h-3" /> Xóa bộ lọc
        </button>
      )}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h2>{currentCategory || (searchQuery ? `Kết quả: "${searchQuery}"` : 'Tất cả sản phẩm')}</h2>
          <p className="text-sm text-muted-foreground">{filteredProducts.length} sản phẩm</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            className="md:hidden gap-2"
            onClick={() => setShowFilters(!showFilters)}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Bộ lọc
          </Button>
          <select
            value={sortBy}
            onChange={e => setSortBy(e.target.value as SortOption)}
            className="text-sm border border-border rounded-lg px-3 py-1.5 bg-white focus:outline-none focus:border-orange-400"
          >
            <option value="newest">Mới nhất</option>
            <option value="sold">Bán chạy</option>
            <option value="rating">Đánh giá cao</option>
            <option value="price-asc">Giá tăng dần</option>
            <option value="price-desc">Giá giảm dần</option>
          </select>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Sidebar - Desktop */}
        <aside className="hidden md:block w-56 shrink-0">
          <div className="bg-white rounded-xl border border-border p-4 sticky top-20">
            <FilterPanel />
          </div>
        </aside>

        {/* Mobile filter overlay */}
        {showFilters && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div className="absolute inset-0 bg-black/40" onClick={() => setShowFilters(false)} />
            <div className="absolute right-0 top-0 bottom-0 w-72 bg-white p-5 overflow-y-auto">
              <div className="flex items-center justify-between mb-4">
                <h3>Bộ lọc</h3>
                <button onClick={() => setShowFilters(false)}><X className="w-5 h-5" /></button>
              </div>
              <FilterPanel />
            </div>
          </div>
        )}

        {/* Product Grid */}
        <div className="flex-1">
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20">
              <span className="text-5xl mb-4 block">🔍</span>
              <h3>Không tìm thấy sản phẩm</h3>
              <p className="text-muted-foreground text-sm mt-2">Thử thay đổi bộ lọc hoặc tìm kiếm khác</p>
              <Button variant="outline" className="mt-4" onClick={clearFilters}>Xóa bộ lọc</Button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredProducts.map(product => (
                <div
                  key={product.id}
                  className="bg-white rounded-xl border border-border overflow-hidden group hover:shadow-lg transition-shadow cursor-pointer"
                  onClick={() => navigate(`/products/${product.id}`)}
                >
                  <div className="relative aspect-square overflow-hidden bg-gray-50">
                    <ImageWithFallback
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    {product.originalPrice && (
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded text-xs text-white" style={{ backgroundColor: '#ea5c21' }}>
                        -{Math.round((1 - product.price / product.originalPrice) * 100)}%
                      </span>
                    )}
                    {product.stock <= 5 && product.stock > 0 && (
                      <span className="absolute top-2 right-2 px-2 py-0.5 rounded text-xs bg-yellow-100 text-yellow-700">
                        Còn {product.stock}
                      </span>
                    )}
                    {product.stock === 0 && (
                      <div className="absolute inset-0 bg-white/60 flex items-center justify-center">
                        <span className="text-sm font-medium text-gray-500">Hết hàng</span>
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <p className="text-xs text-muted-foreground mb-1">{product.category}</p>
                    <h4 className="text-sm mb-1.5 line-clamp-2 hover:text-orange-600">{product.name}</h4>
                    <div className="flex items-center gap-1 mb-2">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-xs text-muted-foreground">{product.rating} ({product.reviewCount})</span>
                      <span className="text-xs text-muted-foreground ml-auto">Đã bán {product.sold}</span>
                    </div>
                    <div className="flex items-center gap-1 mb-2">
                      <span className="text-sm font-semibold" style={{ color: '#ea5c21' }}>{formatPrice(product.price)}</span>
                      {product.originalPrice && (
                        <span className="text-xs text-muted-foreground line-through">{formatPrice(product.originalPrice)}</span>
                      )}
                    </div>
                    <Button
                      size="sm"
                      className="w-full text-xs gap-1.5"
                      style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
                      disabled={product.stock === 0}
                      onClick={e => handleAddToCart(product, e)}
                    >
                      <ShoppingCart className="w-3 h-3" />
                      {product.stock === 0 ? 'Hết hàng' : 'Thêm vào giỏ'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
