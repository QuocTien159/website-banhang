import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { Eye, EyeOff, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../store/AppContext';
import { Button } from '../ui/button';
import { toast } from 'sonner';

export function RegisterPage() {
  const navigate = useNavigate();
  const { register: registerUser } = useAuth();
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!formData.name.trim()) errs.name = 'Vui lòng nhập họ tên';
    if (!formData.email) errs.email = 'Vui lòng nhập email';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) errs.email = 'Email không hợp lệ';
    if (formData.password.length < 6) errs.password = 'Mật khẩu tối thiểu 6 ký tự';
    if (formData.password !== formData.confirmPassword) errs.confirmPassword = 'Mật khẩu không khớp';
    return errs;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setErrors({});
    setLoading(true);
    await new Promise(r => setTimeout(r, 600));
    registerUser(formData.name, formData.email);
    setLoading(false);
    toast.success('Đăng ký thành công! Chào mừng bạn đến với SportZone!');
    navigate('/');
  };

  const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [field]: e.target.value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
  };

  return (
    <div className="min-h-screen flex">
      {/* Left - Illustration */}
      <div className="hidden lg:flex flex-1 items-center justify-center" style={{ background: 'linear-gradient(135deg, #030213 0%, #1a1a3e 100%)' }}>
        <div className="text-center text-white p-12">
          <div className="text-8xl mb-8">🎯</div>
          <h3 className="text-white mb-3" style={{ fontSize: '1.5rem' }}>Tham gia SportZone</h3>
          <p className="text-gray-400 text-sm max-w-xs mb-8">
            Đăng ký thành viên để nhận ưu đãi độc quyền, tích điểm và nhiều quyền lợi hấp dẫn khác.
          </p>
          <div className="space-y-3 text-left">
            {[
              '🎁 Giảm 20% cho đơn hàng đầu tiên',
              '📦 Theo dõi đơn hàng realtime',
              '⭐ Tích điểm đổi quà hấp dẫn',
              '🔔 Nhận thông báo khuyến mãi sớm nhất',
            ].map(benefit => (
              <div key={benefit} className="flex items-center gap-2 bg-white/10 rounded-lg px-4 py-2">
                <span className="text-sm text-gray-300">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right - Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-8">
            <ArrowLeft className="w-4 h-4" /> Về trang chủ
          </Link>

          <div className="flex items-center gap-2 mb-8">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#ea5c21' }}>
              <span className="text-white text-xs font-bold">SZ</span>
            </div>
            <span className="text-lg" style={{ fontWeight: 700 }}>
              Sport<span style={{ color: '#ea5c21' }}>Zone</span>
            </span>
          </div>

          <h2 className="mb-1">Tạo tài khoản</h2>
          <p className="text-sm text-muted-foreground mb-6">Tham gia cộng đồng SportZone ngay hôm nay!</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-1">
              <label className="text-sm font-medium">Họ và tên *</label>
              <input
                type="text"
                value={formData.name}
                onChange={handleChange('name')}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                placeholder="Nguyễn Văn A"
              />
              {errors.name && <p className="text-xs text-red-500">{errors.name}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Email *</label>
              <input
                type="email"
                value={formData.email}
                onChange={handleChange('email')}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                placeholder="example@email.com"
              />
              {errors.email && <p className="text-xs text-red-500">{errors.email}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Mật khẩu *</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={handleChange('password')}
                  className="w-full px-3 py-2 pr-10 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                  placeholder="Ít nhất 6 ký tự"
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {errors.password && <p className="text-xs text-red-500">{errors.password}</p>}
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium">Xác nhận mật khẩu *</label>
              <input
                type="password"
                value={formData.confirmPassword}
                onChange={handleChange('confirmPassword')}
                className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                placeholder="Nhập lại mật khẩu"
              />
              {errors.confirmPassword && <p className="text-xs text-red-500">{errors.confirmPassword}</p>}
            </div>

            <div className="flex items-start gap-2">
              <input type="checkbox" required className="mt-1 accent-orange-500" />
              <p className="text-xs text-muted-foreground">
                Tôi đồng ý với{' '}
                <a href="#" className="hover:underline" style={{ color: '#ea5c21' }}>Điều khoản dịch vụ</a>
                {' '}và{' '}
                <a href="#" className="hover:underline" style={{ color: '#ea5c21' }}>Chính sách bảo mật</a>
              </p>
            </div>

            <Button
              type="submit"
              className="w-full text-white"
              disabled={loading}
              style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
            >
              {loading ? 'Đang tạo tài khoản...' : 'Đăng ký'}
            </Button>
          </form>

          <p className="text-sm text-center text-muted-foreground mt-6">
            Đã có tài khoản?{' '}
            <Link to="/login" className="hover:underline" style={{ color: '#ea5c21' }}>
              Đăng nhập
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
