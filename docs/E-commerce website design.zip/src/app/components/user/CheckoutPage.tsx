import { useNavigate, Link } from 'react-router';
import { useForm } from 'react-hook-form';
import { CreditCard, Truck, CheckCircle } from 'lucide-react';
import { useApp, useCart, ShippingInfo, Order } from '../../store/AppContext';
import { formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner';

export function CheckoutPage() {
  const navigate = useNavigate();
  const { cart, subtotal, shipping, total, dispatch: cartDispatch } = useCart();
  const { state, dispatch } = useApp();
  const user = state.user;

  const { register, handleSubmit, formState: { errors }, watch } = useForm<ShippingInfo>({
    defaultValues: {
      name: user?.name || '',
      phone: user?.phone || '',
      address: user?.address || '',
      paymentMethod: 'cod',
    },
  });

  const paymentMethod = watch('paymentMethod');

  if (cart.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h2>Giỏ hàng trống</h2>
        <Button className="mt-4" onClick={() => navigate('/products')} style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}>
          Tiếp tục mua sắm
        </Button>
      </div>
    );
  }

  const onSubmit = (data: ShippingInfo) => {
    const orderId = `ORD-${Date.now().toString().slice(-6)}`;
    const newOrder: Order = {
      id: orderId,
      userId: user?.id || 'guest',
      userName: data.name,
      items: [...cart],
      subtotal,
      shipping,
      total,
      status: 'pending',
      createdAt: new Date().toISOString(),
      shippingInfo: data,
    };
    dispatch({ type: 'PLACE_ORDER', payload: newOrder });
    cartDispatch({ type: 'CLEAR_CART' });
    toast.success(`Đặt hàng thành công! Mã đơn: ${orderId}`);
    navigate('/account', { state: { orderPlaced: orderId } });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <Link to="/cart" className="hover:text-foreground">Giỏ hàng</Link>
        <span>/</span>
        <span className="text-foreground">Thanh toán</span>
      </div>

      <h2 className="mb-6">Thanh toán</h2>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Shipping Form */}
          <div className="lg:col-span-2 space-y-4">
            {/* Shipping info */}
            <div className="bg-white rounded-xl border border-border p-5">
              <h3 className="text-base font-semibold mb-4 flex items-center gap-2">
                <Truck className="w-4 h-4" style={{ color: '#ea5c21' }} />
                Thông tin giao hàng
              </h3>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Họ và tên *</label>
                  <input
                    {...register('name', { required: 'Vui lòng nhập họ tên' })}
                    className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                    placeholder="Nguyễn Văn A"
                  />
                  {errors.name && <p className="text-xs text-red-500">{errors.name.message}</p>}
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium">Số điện thoại *</label>
                  <input
                    {...register('phone', {
                      required: 'Vui lòng nhập số điện thoại',
                      pattern: { value: /^[0-9]{10,11}$/, message: 'Số điện thoại không hợp lệ' },
                    })}
                    className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                    placeholder="0912 345 678"
                  />
                  {errors.phone && <p className="text-xs text-red-500">{errors.phone.message}</p>}
                </div>
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-sm font-medium">Địa chỉ giao hàng *</label>
                  <input
                    {...register('address', { required: 'Vui lòng nhập địa chỉ' })}
                    className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background"
                    placeholder="Số nhà, tên đường, phường/xã, quận/huyện, tỉnh/thành phố"
                  />
                  {errors.address && <p className="text-xs text-red-500">{errors.address.message}</p>}
                </div>
                <div className="sm:col-span-2 space-y-1">
                  <label className="text-sm font-medium">Ghi chú (tùy chọn)</label>
                  <textarea
                    {...register('note')}
                    rows={2}
                    className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-input-background resize-none"
                    placeholder="Ghi chú thêm cho đơn hàng..."
                  />
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white rounded-xl border border-border p-5">
              <h3 className="text-base font-semibold mb-4 flex items-center gap-2">
                <CreditCard className="w-4 h-4" style={{ color: '#ea5c21' }} />
                Phương thức thanh toán
              </h3>
              <div className="space-y-3">
                {[
                  { value: 'cod', label: 'Thanh toán khi nhận hàng (COD)', sub: 'Trả tiền mặt khi shipper giao hàng', icon: '💵' },
                  { value: 'banking', label: 'Chuyển khoản ngân hàng', sub: 'Thanh toán qua internet banking / QR code', icon: '🏦' },
                ].map(option => (
                  <label
                    key={option.value}
                    className={`flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${paymentMethod === option.value ? 'border-orange-400 bg-orange-50' : 'border-border hover:border-orange-300'}`}
                  >
                    <input
                      type="radio"
                      value={option.value}
                      {...register('paymentMethod')}
                      className="mt-0.5 accent-orange-500"
                    />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span>{option.icon}</span>
                        <span className="text-sm font-medium">{option.label}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">{option.sub}</p>
                    </div>
                  </label>
                ))}
              </div>

              {paymentMethod === 'banking' && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm font-medium text-blue-800 mb-2">Thông tin chuyển khoản:</p>
                  <div className="space-y-1 text-sm text-blue-700">
                    <p>Ngân hàng: <strong>Vietcombank</strong></p>
                    <p>Số TK: <strong>1234 5678 9012</strong></p>
                    <p>Chủ TK: <strong>CONG TY SPORTZONE</strong></p>
                    <p>Nội dung: <strong>TEN_SDT_ORDERNUMBER</strong></p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-white rounded-xl border border-border p-4 sticky top-20">
              <h4 className="text-sm font-semibold mb-4">Đơn hàng ({cart.length} sản phẩm)</h4>
              <div className="space-y-3 max-h-64 overflow-y-auto mb-4">
                {cart.map(item => (
                  <div key={item.product.id} className="flex gap-3">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-50 shrink-0">
                      <ImageWithFallback src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs truncate">{item.product.name}</p>
                      <p className="text-xs text-muted-foreground">x{item.quantity}</p>
                    </div>
                    <span className="text-xs font-medium shrink-0">{formatPrice(item.product.price * item.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="space-y-2 border-t border-border pt-3">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Tạm tính</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Vận chuyển</span>
                  <span className={shipping === 0 ? 'text-green-600' : ''}>{shipping === 0 ? 'Miễn phí' : formatPrice(shipping)}</span>
                </div>
                <div className="flex justify-between font-semibold border-t border-border pt-2">
                  <span>Tổng cộng</span>
                  <span style={{ color: '#ea5c21' }}>{formatPrice(total)}</span>
                </div>
              </div>
              <Button
                type="submit"
                className="w-full mt-4 gap-2 text-white"
                style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}
              >
                <CheckCircle className="w-4 h-4" />
                Đặt hàng
              </Button>
              <p className="text-xs text-muted-foreground text-center mt-2">
                Bằng cách đặt hàng, bạn đồng ý với điều khoản sử dụng của chúng tôi
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
