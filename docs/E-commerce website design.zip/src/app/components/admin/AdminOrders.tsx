import { useState } from 'react';
import { Search, Eye, ChevronDown } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { Order } from '../../store/AppContext';
import { formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { toast } from 'sonner';

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  confirmed: 'bg-blue-100 text-blue-700',
  shipping: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

const STATUS_LABELS: Record<string, string> = {
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  shipping: 'Đang giao',
  delivered: 'Đã giao',
  cancelled: 'Đã hủy',
};

const STATUS_TRANSITIONS: Record<string, Order['status'][]> = {
  pending: ['confirmed', 'cancelled'],
  confirmed: ['shipping', 'cancelled'],
  shipping: ['delivered'],
  delivered: [],
  cancelled: [],
};

export function AdminOrders() {
  const { state, dispatch } = useApp();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [viewOrder, setViewOrder] = useState<Order | null>(null);

  const filtered = state.orders.filter(o => {
    const matchSearch = o.id.toLowerCase().includes(search.toLowerCase()) ||
      o.userName.toLowerCase().includes(search.toLowerCase()) ||
      o.shippingInfo.phone.includes(search);
    const matchStatus = !statusFilter || o.status === statusFilter;
    return matchSearch && matchStatus;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  const handleStatusChange = (orderId: string, newStatus: Order['status']) => {
    dispatch({ type: 'UPDATE_ORDER_STATUS', payload: { orderId, status: newStatus } });
    toast.success(`Đã cập nhật trạng thái đơn ${orderId}`);
  };

  const formatDate = (iso: string) => new Date(iso).toLocaleDateString('vi-VN', {
    day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });

  const totalRevenue = state.orders.filter(o => o.status !== 'cancelled').reduce((s, o) => s + o.total, 0);

  return (
    <div className="space-y-5">
      <div>
        <h2>Quản lý đơn hàng</h2>
        <p className="text-sm text-muted-foreground">{state.orders.length} đơn hàng · Doanh thu: {formatPrice(totalRevenue)}</p>
      </div>

      {/* Status tabs */}
      <div className="flex gap-2 flex-wrap">
        {[{ value: '', label: 'Tất cả', count: state.orders.length }, ...Object.entries(STATUS_LABELS).map(([k, v]) => ({ value: k, label: v, count: state.orders.filter(o => o.status === k).length }))].map(tab => (
          <button
            key={tab.value}
            onClick={() => setStatusFilter(tab.value)}
            className={`px-3 py-1.5 rounded-lg text-sm transition-colors flex items-center gap-1.5 ${statusFilter === tab.value ? 'text-white' : 'bg-white border border-border text-muted-foreground hover:border-orange-300'}`}
            style={statusFilter === tab.value ? { backgroundColor: '#ea5c21' } : {}}
          >
            {tab.label}
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${statusFilter === tab.value ? 'bg-white/20 text-white' : 'bg-gray-100'}`}>{tab.count}</span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Tìm theo mã đơn, tên khách, số điện thoại..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-white"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Mã đơn</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Khách hàng</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Thời gian</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Tổng tiền</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Thanh toán</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Trạng thái</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(order => (
                <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <span className="font-medium text-sm">{order.id}</span>
                    <p className="text-xs text-muted-foreground">{order.items.length} sản phẩm</p>
                  </td>
                  <td className="px-4 py-3">
                    <p className="font-medium">{order.userName}</p>
                    <p className="text-xs text-muted-foreground">{order.shippingInfo.phone}</p>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground">{formatDate(order.createdAt)}</td>
                  <td className="px-4 py-3 text-right font-semibold" style={{ color: '#ea5c21' }}>{formatPrice(order.total)}</td>
                  <td className="px-4 py-3 text-center">
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">
                      {order.shippingInfo.paymentMethod === 'cod' ? 'COD' : 'Ngân hàng'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <div className="relative inline-block">
                      {STATUS_TRANSITIONS[order.status].length > 0 ? (
                        <select
                          value={order.status}
                          onChange={e => handleStatusChange(order.id, e.target.value as Order['status'])}
                          className={`text-xs px-2 py-1 rounded-full border-0 font-medium cursor-pointer appearance-none pr-5 ${STATUS_COLORS[order.status]}`}
                        >
                          <option value={order.status}>{STATUS_LABELS[order.status]}</option>
                          {STATUS_TRANSITIONS[order.status].map(s => (
                            <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                          ))}
                        </select>
                      ) : (
                        <span className={`text-xs px-2 py-1 rounded-full font-medium ${STATUS_COLORS[order.status]}`}>
                          {STATUS_LABELS[order.status]}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => setViewOrder(order)}
                      className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-600 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-12 text-center text-muted-foreground text-sm">Không có đơn hàng nào</div>
          )}
        </div>
      </div>

      {/* View Order Modal */}
      {viewOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-5 border-b border-border flex items-center justify-between">
              <div>
                <h3>Chi tiết đơn hàng</h3>
                <p className="text-sm text-muted-foreground">{viewOrder.id} · {formatDate(viewOrder.createdAt)}</p>
              </div>
              <span className={`text-xs px-3 py-1.5 rounded-full font-medium ${STATUS_COLORS[viewOrder.status]}`}>
                {STATUS_LABELS[viewOrder.status]}
              </span>
            </div>
            <div className="p-5 space-y-5">
              {/* Customer */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Thông tin giao hàng</p>
                <div className="bg-gray-50 rounded-lg p-3 space-y-1 text-sm">
                  <p><strong>Tên:</strong> {viewOrder.shippingInfo.name}</p>
                  <p><strong>SĐT:</strong> {viewOrder.shippingInfo.phone}</p>
                  <p><strong>Địa chỉ:</strong> {viewOrder.shippingInfo.address}</p>
                  {viewOrder.shippingInfo.note && <p><strong>Ghi chú:</strong> {viewOrder.shippingInfo.note}</p>}
                  <p><strong>Thanh toán:</strong> {viewOrder.shippingInfo.paymentMethod === 'cod' ? 'COD' : 'Chuyển khoản'}</p>
                </div>
              </div>
              {/* Items */}
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Sản phẩm</p>
                <div className="space-y-2">
                  {viewOrder.items.map(item => (
                    <div key={item.product.id} className="flex justify-between items-center text-sm p-2 bg-gray-50 rounded-lg">
                      <span className="flex-1 truncate mr-2">{item.product.name}</span>
                      <span className="text-muted-foreground shrink-0">x{item.quantity}</span>
                      <span className="font-medium ml-3 shrink-0" style={{ color: '#ea5c21' }}>{formatPrice(item.product.price * item.quantity)}</span>
                    </div>
                  ))}
                </div>
              </div>
              {/* Total */}
              <div className="border-t border-border pt-3 space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tạm tính</span>
                  <span>{formatPrice(viewOrder.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Vận chuyển</span>
                  <span>{viewOrder.shipping === 0 ? 'Miễn phí' : formatPrice(viewOrder.shipping)}</span>
                </div>
                <div className="flex justify-between font-semibold text-base pt-1">
                  <span>Tổng cộng</span>
                  <span style={{ color: '#ea5c21' }}>{formatPrice(viewOrder.total)}</span>
                </div>
              </div>
            </div>
            <div className="p-5 border-t border-border">
              <Button variant="outline" className="w-full" onClick={() => setViewOrder(null)}>Đóng</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
