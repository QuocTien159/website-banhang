import { useNavigate } from 'react-router';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, ShoppingBag, Users, Package, ArrowUpRight, Clock } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { formatPrice } from '../../data/products';

const MONTHLY_REVENUE = [
  { month: 'T1', revenue: 12500000, orders: 48 },
  { month: 'T2', revenue: 15800000, orders: 62 },
  { month: 'T3', revenue: 13200000, orders: 51 },
  { month: 'T4', revenue: 18900000, orders: 74 },
  { month: 'T5', revenue: 21300000, orders: 89 },
  { month: 'T6', revenue: 17600000, orders: 68 },
];

const STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-700',
  confirmed: 'bg-blue-100 text-blue-700',
  shipping: 'bg-purple-100 text-purple-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-red-100 text-red-700',
};

const STATUS_LABELS: Record<string, string> = {
  pending: 'Chờ xác nhận',
  confirmed: 'Đã xác nhận',
  shipping: 'Đang giao',
  delivered: 'Đã giao',
  cancelled: 'Đã hủy',
};

export function AdminDashboard() {
  const { state } = useApp();
  const navigate = useNavigate();

  const totalRevenue = state.orders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);
  const totalOrders = state.orders.length;
  const pendingOrders = state.orders.filter(o => o.status === 'pending').length;
  const totalCustomers = state.customers.length;
  const totalProducts = state.products.length;
  const lowStockProducts = state.products.filter(p => p.stock <= 5).length;

  const recentOrders = [...state.orders].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 6);

  const topProducts = [...state.products].sort((a, b) => b.sold - a.sold).slice(0, 5);

  const formatDate = (iso: string) => new Date(iso).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2>Tổng quan</h2>
        <p className="text-sm text-muted-foreground">Chào mừng trở lại! Đây là tình trạng cửa hàng hôm nay.</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Doanh thu', value: formatPrice(totalRevenue), sub: '+12.5% so với tháng trước', icon: TrendingUp, color: '#ea5c21', bg: 'bg-orange-50' },
          { label: 'Đơn hàng', value: totalOrders, sub: `${pendingOrders} chờ xác nhận`, icon: ShoppingBag, color: '#3b82f6', bg: 'bg-blue-50' },
          { label: 'Khách hàng', value: totalCustomers, sub: '+3 khách mới tháng này', icon: Users, color: '#10b981', bg: 'bg-green-50' },
          { label: 'Sản phẩm', value: totalProducts, sub: `${lowStockProducts} sp sắp hết`, icon: Package, color: '#8b5cf6', bg: 'bg-purple-50' },
        ].map(stat => (
          <div key={stat.label} className="bg-white rounded-xl border border-border p-4">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl ${stat.bg} flex items-center justify-center`}>
                <stat.icon className="w-5 h-5" style={{ color: stat.color }} />
              </div>
              <ArrowUpRight className="w-4 h-4 text-green-500" />
            </div>
            <p className="text-xl font-bold">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
            <p className="text-xs text-green-600 mt-1">{stat.sub}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid lg:grid-cols-2 gap-4">
        {/* Revenue Chart */}
        <div className="bg-white rounded-xl border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <h4>Doanh thu 6 tháng</h4>
            <span className="text-xs text-muted-foreground">Triệu đồng</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={MONTHLY_REVENUE}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} tickFormatter={v => `${(v / 1000000).toFixed(0)}M`} />
              <Tooltip formatter={(value: number) => [formatPrice(value), 'Doanh thu']} />
              <Bar dataKey="revenue" fill="#ea5c21" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Orders Chart */}
        <div className="bg-white rounded-xl border border-border p-4">
          <div className="flex items-center justify-between mb-4">
            <h4>Đơn hàng 6 tháng</h4>
            <span className="text-xs text-muted-foreground">Số đơn</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={MONTHLY_REVENUE}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="month" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(value: number) => [value, 'Đơn hàng']} />
              <Line type="monotone" dataKey="orders" stroke="#3b82f6" strokeWidth={2} dot={{ fill: '#3b82f6', r: 4 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Orders + Top Products */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* Recent Orders */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-border">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h4 className="flex items-center gap-2">
              <Clock className="w-4 h-4" style={{ color: '#ea5c21' }} />
              Đơn hàng gần đây
            </h4>
            <button
              onClick={() => navigate('/admin/orders')}
              className="text-xs hover:underline"
              style={{ color: '#ea5c21' }}
            >
              Xem tất cả →
            </button>
          </div>
          <div className="divide-y divide-border">
            {recentOrders.map(order => (
              <div key={order.id} className="p-4 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium">{order.id}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full ${STATUS_COLORS[order.status]}`}>
                      {STATUS_LABELS[order.status]}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-0.5">{order.userName} · {formatDate(order.createdAt)}</p>
                </div>
                <span className="text-sm font-semibold shrink-0" style={{ color: '#ea5c21' }}>
                  {formatPrice(order.total)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Products */}
        <div className="bg-white rounded-xl border border-border">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h4>Bán chạy nhất</h4>
            <button onClick={() => navigate('/admin/products')} className="text-xs hover:underline" style={{ color: '#ea5c21' }}>
              Xem tất cả →
            </button>
          </div>
          <div className="divide-y divide-border">
            {topProducts.map((product, i) => (
              <div key={product.id} className="p-3 flex items-center gap-3">
                <span className="w-5 h-5 rounded flex items-center justify-center text-xs font-bold shrink-0" style={{ color: i < 3 ? '#ea5c21' : '#999' }}>
                  {i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs truncate">{product.name}</p>
                  <p className="text-xs text-muted-foreground">Đã bán: {product.sold}</p>
                </div>
                <span className="text-xs font-medium shrink-0" style={{ color: '#ea5c21' }}>
                  {formatPrice(product.price)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Order Status Summary */}
      <div className="bg-white rounded-xl border border-border p-4">
        <h4 className="mb-4">Trạng thái đơn hàng</h4>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {Object.entries(STATUS_LABELS).map(([status, label]) => {
            const count = state.orders.filter(o => o.status === status).length;
            return (
              <div key={status} className={`rounded-xl p-3 text-center ${STATUS_COLORS[status]}`}>
                <p className="text-2xl font-bold">{count}</p>
                <p className="text-xs mt-0.5">{label}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
