import { useState } from 'react';
import { Plus, Search, Edit2, Trash2, AlertTriangle } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { Product, CATEGORIES, formatPrice } from '../../data/products';
import { Button } from '../ui/button';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { toast } from 'sonner';

const EMPTY_FORM = {
  name: '', category: 'Gym & Fitness' as Product['category'], price: '', originalPrice: '',
  image: '', description: '', stock: '', rating: '4.5', reviewCount: '0', sold: '0',
};

export function AdminProducts() {
  const { state, dispatch } = useApp();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [editProduct, setEditProduct] = useState<Product | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const filtered = state.products.filter(p => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchCat = !categoryFilter || p.category === categoryFilter;
    return matchSearch && matchCat;
  });

  const openAdd = () => {
    setEditProduct(null);
    setForm(EMPTY_FORM);
    setShowModal(true);
  };

  const openEdit = (product: Product) => {
    setEditProduct(product);
    setForm({
      name: product.name,
      category: product.category,
      price: String(product.price),
      originalPrice: String(product.originalPrice || ''),
      image: product.image,
      description: product.description,
      stock: String(product.stock),
      rating: String(product.rating),
      reviewCount: String(product.reviewCount),
      sold: String(product.sold),
    });
    setShowModal(true);
  };

  const handleSave = () => {
    if (!form.name.trim() || !form.price || !form.stock) {
      toast.error('Vui lòng điền đầy đủ các trường bắt buộc');
      return;
    }
    const productData: Product = {
      id: editProduct?.id || `p_${Date.now()}`,
      name: form.name,
      category: form.category,
      price: parseInt(form.price),
      originalPrice: form.originalPrice ? parseInt(form.originalPrice) : undefined,
      image: form.image || `https://images.unsplash.com/photo-1562771242-a02d9090c90c?w=600&auto=format`,
      description: form.description,
      specs: editProduct?.specs || [],
      stock: parseInt(form.stock),
      rating: parseFloat(form.rating),
      reviewCount: parseInt(form.reviewCount),
      featured: editProduct?.featured || false,
      sold: parseInt(form.sold),
    };
    if (editProduct) {
      dispatch({ type: 'UPDATE_PRODUCT', payload: productData });
      toast.success('Đã cập nhật sản phẩm!');
    } else {
      dispatch({ type: 'ADD_PRODUCT', payload: productData });
      toast.success('Đã thêm sản phẩm mới!');
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    dispatch({ type: 'DELETE_PRODUCT', payload: id });
    toast.success('Đã xóa sản phẩm');
    setDeleteConfirm(null);
  };

  const handleFormChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setForm(prev => ({ ...prev, [field]: e.target.value }));
  };

  const lowStock = state.products.filter(p => p.stock <= 5).length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2>Quản lý sản phẩm</h2>
          <p className="text-sm text-muted-foreground">{state.products.length} sản phẩm · {lowStock} sắp hết hàng</p>
        </div>
        <Button onClick={openAdd} className="gap-2 text-white" style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}>
          <Plus className="w-4 h-4" /> Thêm sản phẩm
        </Button>
      </div>

      {/* Warning */}
      {lowStock > 0 && (
        <div className="flex items-center gap-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <AlertTriangle className="w-4 h-4 text-yellow-600 shrink-0" />
          <p className="text-sm text-yellow-700">{lowStock} sản phẩm có tồn kho ≤ 5. Kiểm tra và bổ sung hàng.</p>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm sản phẩm..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-white"
          />
        </div>
        <select
          value={categoryFilter}
          onChange={e => setCategoryFilter(e.target.value)}
          className="px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-white"
        >
          <option value="">Tất cả danh mục</option>
          {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Sản phẩm</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Danh mục</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Giá</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Tồn kho</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Đã bán</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Trạng thái</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(product => (
                <tr key={product.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-gray-100 shrink-0">
                        <ImageWithFallback src={product.image} alt={product.name} className="w-full h-full object-cover" />
                      </div>
                      <div>
                        <p className="font-medium truncate max-w-[180px]">{product.name}</p>
                        <p className="text-xs text-muted-foreground">⭐ {product.rating}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs px-2 py-1 rounded-full bg-gray-100 text-gray-600">{product.category}</span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <p className="font-medium" style={{ color: '#ea5c21' }}>{formatPrice(product.price)}</p>
                    {product.originalPrice && (
                      <p className="text-xs text-muted-foreground line-through">{formatPrice(product.originalPrice)}</p>
                    )}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs font-medium ${product.stock <= 5 ? 'text-red-600' : product.stock <= 20 ? 'text-yellow-600' : 'text-green-600'}`}>
                      {product.stock}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-center text-sm text-muted-foreground">{product.sold}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-xs px-2 py-1 rounded-full ${product.stock > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                      {product.stock > 0 ? 'Còn hàng' : 'Hết hàng'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-2">
                      <button onClick={() => openEdit(product)} className="p-1.5 rounded-lg hover:bg-blue-50 text-blue-600 transition-colors">
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button onClick={() => setDeleteConfirm(product.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-red-500 transition-colors">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-12 text-center text-muted-foreground text-sm">Không tìm thấy sản phẩm nào</div>
          )}
        </div>
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-5 border-b border-border">
              <h3>{editProduct ? 'Chỉnh sửa sản phẩm' : 'Thêm sản phẩm mới'}</h3>
            </div>
            <div className="p-5 space-y-4">
              <div className="space-y-1">
                <label className="text-sm font-medium">Tên sản phẩm *</label>
                <input value={form.name} onChange={handleFormChange('name')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400" placeholder="Tên sản phẩm..." />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Danh mục *</label>
                  <select value={form.category} onChange={handleFormChange('category')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400">
                    {CATEGORIES.map(c => <option key={c.name} value={c.name}>{c.name}</option>)}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium">Tồn kho *</label>
                  <input type="number" value={form.stock} onChange={handleFormChange('stock')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400" placeholder="0" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-sm font-medium">Giá bán (đ) *</label>
                  <input type="number" value={form.price} onChange={handleFormChange('price')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400" placeholder="350000" />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium">Giá gốc (đ)</label>
                  <input type="number" value={form.originalPrice} onChange={handleFormChange('originalPrice')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400" placeholder="420000 (tùy chọn)" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">URL ảnh sản phẩm</label>
                <input value={form.image} onChange={handleFormChange('image')} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400" placeholder="https://..." />
              </div>
              <div className="space-y-1">
                <label className="text-sm font-medium">Mô tả</label>
                <textarea value={form.description} onChange={handleFormChange('description')} rows={3} className="w-full px-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 resize-none" placeholder="Mô tả sản phẩm..." />
              </div>
            </div>
            <div className="p-5 border-t border-border flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setShowModal(false)}>Hủy</Button>
              <Button onClick={handleSave} className="text-white" style={{ backgroundColor: '#ea5c21', borderColor: '#ea5c21' }}>
                {editProduct ? 'Cập nhật' : 'Thêm sản phẩm'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-red-500" />
              </div>
              <div>
                <h4>Xóa sản phẩm?</h4>
                <p className="text-sm text-muted-foreground">Thao tác này không thể hoàn tác</p>
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <Button variant="outline" onClick={() => setDeleteConfirm(null)}>Hủy</Button>
              <Button variant="destructive" onClick={() => handleDelete(deleteConfirm)}>Xóa</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
