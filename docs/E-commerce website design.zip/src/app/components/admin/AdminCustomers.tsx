import { useState } from 'react';
import { Search, User, Phone, MapPin, Calendar } from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { formatPrice } from '../../data/products';

export function AdminCustomers() {
  const { state } = useApp();
  const [search, setSearch] = useState('');

  const filtered = state.customers.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    c.email.toLowerCase().includes(search.toLowerCase()) ||
    c.phone.includes(search)
  );

  const getCustomerStats = (customerId: string) => {
    const orders = state.orders.filter(o => o.userId === customerId);
    const totalSpent = orders.filter(o => o.status !== 'cancelled').reduce((s, o) => s + o.total, 0);
    return { orders: orders.length, totalSpent };
  };

  const totalRevenue = state.customers.reduce((sum, c) => {
    const { totalSpent } = getCustomerStats(c.id);
    return sum + totalSpent;
  }, 0);

  return (
    <div className="space-y-5">
      {/* Header */}
      <div>
        <h2>Quản lý khách hàng</h2>
        <p className="text-sm text-muted-foreground">{state.customers.length} khách hàng · Tổng doanh thu: {formatPrice(totalRevenue)}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Tổng khách hàng', value: state.customers.length, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Khách mua hàng', value: state.customers.filter(c => getCustomerStats(c.id).orders > 0).length, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Mua lại', value: state.customers.filter(c => getCustomerStats(c.id).orders > 1).length, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Tổng doanh thu', value: formatPrice(totalRevenue), color: 'text-orange-600', bg: 'bg-orange-50' },
        ].map(stat => (
          <div key={stat.label} className={`${stat.bg} rounded-xl p-4`}>
            <p className={`text-xl font-bold ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-muted-foreground mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          type="text"
          placeholder="Tìm theo tên, email, số điện thoại..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          className="w-full pl-9 pr-3 py-2 text-sm border border-border rounded-lg focus:outline-none focus:border-orange-400 bg-white"
        />
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-border">
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Khách hàng</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase hidden md:table-cell">Liên hệ</th>
                <th className="text-left px-4 py-3 text-xs font-medium text-muted-foreground uppercase hidden lg:table-cell">Địa chỉ</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Đơn hàng</th>
                <th className="text-right px-4 py-3 text-xs font-medium text-muted-foreground uppercase">Tổng chi</th>
                <th className="text-center px-4 py-3 text-xs font-medium text-muted-foreground uppercase hidden md:table-cell">Ngày tham gia</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map(customer => {
                const { orders, totalSpent } = getCustomerStats(customer.id);
                return (
                  <tr key={customer.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full flex items-center justify-center text-white text-sm font-medium shrink-0" style={{ backgroundColor: '#ea5c21' }}>
                          {customer.name.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium">{customer.name}</p>
                          <p className="text-xs text-muted-foreground">{customer.email}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                        <Phone className="w-3 h-3" />
                        {customer.phone}
                      </div>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell">
                      <div className="flex items-start gap-1.5 text-xs text-muted-foreground max-w-[180px]">
                        <MapPin className="w-3 h-3 shrink-0 mt-0.5" />
                        <span className="truncate">{customer.address}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span className={`text-sm font-medium px-2 py-1 rounded-full ${orders > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {orders}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <span className="font-semibold" style={{ color: totalSpent > 0 ? '#ea5c21' : undefined }}>
                        {totalSpent > 0 ? formatPrice(totalSpent) : '-'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center hidden md:table-cell">
                      <div className="flex items-center justify-center gap-1 text-xs text-muted-foreground">
                        <Calendar className="w-3 h-3" />
                        {customer.joinDate}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="py-12 text-center text-muted-foreground text-sm">Không tìm thấy khách hàng nào</div>
          )}
        </div>
      </div>
    </div>
  );
}
