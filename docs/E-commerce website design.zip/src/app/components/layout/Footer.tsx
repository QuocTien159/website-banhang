import { Link } from 'react-router';
import { Facebook, Instagram, Youtube, Phone, Mail, MapPin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#030213] text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#ea5c21' }}>
                <span className="text-white text-xs font-bold">SZ</span>
              </div>
              <span className="text-lg" style={{ fontWeight: 700 }}>
                Sport<span style={{ color: '#ea5c21' }}>Zone</span>
              </span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-4">
              Hệ thống cửa hàng dụng cụ thể thao uy tín hàng đầu Việt Nam. Chất lượng đảm bảo, giá cả hợp lý.
            </p>
            <div className="flex gap-3">
              {[
                { icon: Facebook, href: '#' },
                { icon: Instagram, href: '#' },
                { icon: Youtube, href: '#' },
              ].map(({ icon: Icon, href }, i) => (
                <a key={i} href={href} className="w-8 h-8 rounded-full bg-white/10 hover:bg-orange-500 flex items-center justify-center transition-colors">
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white">Danh mục</h4>
            <ul className="space-y-2">
              {['Gym & Fitness', 'Chạy bộ', 'Bóng đá', 'Bóng rổ', 'Tennis', 'Bơi lội'].map(cat => (
                <li key={cat}>
                  <Link
                    to={`/products?category=${encodeURIComponent(cat)}`}
                    className="text-sm text-gray-400 hover:text-orange-400 transition-colors"
                  >
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Policy */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white">Hỗ trợ</h4>
            <ul className="space-y-2">
              {[
                'Chính sách giao hàng',
                'Chính sách đổi trả',
                'Chính sách bảo hành',
                'Hướng dẫn mua hàng',
                'Câu hỏi thường gặp',
                'Liên hệ',
              ].map(item => (
                <li key={item}>
                  <a href="#" className="text-sm text-gray-400 hover:text-orange-400 transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold mb-4 text-white">Liên hệ</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-orange-400 shrink-0 mt-0.5" />
                <span className="text-sm text-gray-400">123 Nguyễn Thị Minh Khai, Q.1, TP. Hồ Chí Minh</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-orange-400 shrink-0" />
                <span className="text-sm text-gray-400">1800 1234 (Miễn phí)</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-400 shrink-0" />
                <span className="text-sm text-gray-400">hello@sportzone.vn</span>
              </li>
            </ul>
            <div className="mt-4 p-3 bg-white/5 rounded-lg">
              <p className="text-xs text-gray-400">Giờ làm việc:</p>
              <p className="text-sm text-white">T2 - T7: 8:00 - 21:00</p>
              <p className="text-sm text-white">CN: 9:00 - 18:00</p>
            </div>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-gray-500">© 2026 SportZone. Tất cả quyền được bảo lưu.</p>
          <div className="flex items-center gap-4">
            <img src="https://cdn.haitrieu.com/wp-content/uploads/2022/10/Logo-VNPAY-QR-1.png" alt="VNPAY" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
            <img src="https://cdn.haitrieu.com/wp-content/uploads/2022/10/Icon-MoMo-Circle.png" alt="MoMo" className="h-6 opacity-60 hover:opacity-100 transition-opacity" />
          </div>
        </div>
      </div>
    </footer>
  );
}
