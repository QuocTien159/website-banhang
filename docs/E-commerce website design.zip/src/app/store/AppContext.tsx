import { createContext, useContext, useReducer, ReactNode } from 'react';
import { Product, PRODUCTS } from '../data/products';

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  phone: string;
  address: string;
  joinDate: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ShippingInfo {
  name: string;
  phone: string;
  address: string;
  note?: string;
  paymentMethod: 'cod' | 'banking';
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  items: CartItem[];
  subtotal: number;
  shipping: number;
  total: number;
  status: 'pending' | 'confirmed' | 'shipping' | 'delivered' | 'cancelled';
  createdAt: string;
  shippingInfo: ShippingInfo;
}

interface AppState {
  user: User | null;
  cart: CartItem[];
  orders: Order[];
  products: Product[];
  customers: User[];
}

type Action =
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'ADD_TO_CART'; payload: Product }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'UPDATE_CART_QUANTITY'; payload: { productId: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'PLACE_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER_STATUS'; payload: { orderId: string; status: Order['status'] } }
  | { type: 'ADD_PRODUCT'; payload: Product }
  | { type: 'UPDATE_PRODUCT'; payload: Product }
  | { type: 'DELETE_PRODUCT'; payload: string };

const DEMO_CUSTOMERS: User[] = [
  { id: 'u1', name: 'Nguyễn Văn An', email: 'an.nguyen@gmail.com', role: 'user', phone: '0912 345 678', address: '123 Lê Lợi, Q.1, TP.HCM', joinDate: '2024-03-15' },
  { id: 'u2', name: 'Trần Thị Bích', email: 'bich.tran@yahoo.com', role: 'user', phone: '0987 654 321', address: '45 Nguyễn Huệ, Q.1, TP.HCM', joinDate: '2024-05-22' },
  { id: 'u3', name: 'Lê Minh Cường', email: 'cuong.le@hotmail.com', role: 'user', phone: '0905 111 222', address: '89 Trần Hưng Đạo, Q.5, TP.HCM', joinDate: '2024-07-08' },
  { id: 'u4', name: 'Phạm Thị Dung', email: 'dung.pham@gmail.com', role: 'user', phone: '0932 888 999', address: '12 Hai Bà Trưng, Q.3, TP.HCM', joinDate: '2024-08-19' },
  { id: 'u5', name: 'Hoàng Văn Em', email: 'em.hoang@gmail.com', role: 'user', phone: '0976 444 555', address: '67 Điện Biên Phủ, Q.Bình Thạnh, TP.HCM', joinDate: '2024-10-30' },
  { id: 'u6', name: 'Vũ Thị Phượng', email: 'phuong.vu@gmail.com', role: 'user', phone: '0908 777 666', address: '34 Lý Thường Kiệt, Q.10, TP.HCM', joinDate: '2025-01-14' },
];

const DEMO_ORDERS: Order[] = [
  {
    id: 'ORD-001',
    userId: 'u1',
    userName: 'Nguyễn Văn An',
    items: [{ product: PRODUCTS[0], quantity: 2 }, { product: PRODUCTS[2], quantity: 1 }],
    subtotal: 985000,
    shipping: 30000,
    total: 1015000,
    status: 'delivered',
    createdAt: '2025-05-01T10:30:00',
    shippingInfo: { name: 'Nguyễn Văn An', phone: '0912 345 678', address: '123 Lê Lợi, Q.1, TP.HCM', paymentMethod: 'cod' },
  },
  {
    id: 'ORD-002',
    userId: 'u2',
    userName: 'Trần Thị Bích',
    items: [{ product: PRODUCTS[4], quantity: 1 }],
    subtotal: 1250000,
    shipping: 0,
    total: 1250000,
    status: 'shipping',
    createdAt: '2025-05-10T14:20:00',
    shippingInfo: { name: 'Trần Thị Bích', phone: '0987 654 321', address: '45 Nguyễn Huệ, Q.1, TP.HCM', paymentMethod: 'banking' },
  },
  {
    id: 'ORD-003',
    userId: 'u3',
    userName: 'Lê Minh Cường',
    items: [{ product: PRODUCTS[8], quantity: 1 }, { product: PRODUCTS[5], quantity: 1 }],
    subtotal: 2830000,
    shipping: 0,
    total: 2830000,
    status: 'confirmed',
    createdAt: '2025-05-12T09:15:00',
    shippingInfo: { name: 'Lê Minh Cường', phone: '0905 111 222', address: '89 Trần Hưng Đạo, Q.5, TP.HCM', paymentMethod: 'banking' },
  },
  {
    id: 'ORD-004',
    userId: 'u4',
    userName: 'Phạm Thị Dung',
    items: [{ product: PRODUCTS[2], quantity: 2 }, { product: PRODUCTS[3], quantity: 1 }, { product: PRODUCTS[13], quantity: 1 }],
    subtotal: 845000,
    shipping: 30000,
    total: 875000,
    status: 'pending',
    createdAt: '2025-05-15T16:45:00',
    shippingInfo: { name: 'Phạm Thị Dung', phone: '0932 888 999', address: '12 Hai Bà Trưng, Q.3, TP.HCM', paymentMethod: 'cod' },
  },
  {
    id: 'ORD-005',
    userId: 'u5',
    userName: 'Hoàng Văn Em',
    items: [{ product: PRODUCTS[6], quantity: 3 }],
    subtotal: 960000,
    shipping: 0,
    total: 960000,
    status: 'delivered',
    createdAt: '2025-05-08T11:00:00',
    shippingInfo: { name: 'Hoàng Văn Em', phone: '0976 444 555', address: '67 Điện Biên Phủ, Q.Bình Thạnh, TP.HCM', paymentMethod: 'cod' },
  },
  {
    id: 'ORD-006',
    userId: 'u6',
    userName: 'Vũ Thị Phượng',
    items: [{ product: PRODUCTS[1], quantity: 1 }, { product: PRODUCTS[15], quantity: 2 }],
    subtotal: 1180000,
    shipping: 0,
    total: 1180000,
    status: 'cancelled',
    createdAt: '2025-05-05T08:30:00',
    shippingInfo: { name: 'Vũ Thị Phượng', phone: '0908 777 666', address: '34 Lý Thường Kiệt, Q.10, TP.HCM', paymentMethod: 'cod' },
  },
];

const initialState: AppState = {
  user: null,
  cart: [],
  orders: DEMO_ORDERS,
  products: PRODUCTS,
  customers: DEMO_CUSTOMERS,
};

function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'LOGIN':
      return { ...state, user: action.payload };
    case 'LOGOUT':
      return { ...state, user: null, cart: [] };
    case 'ADD_TO_CART': {
      const existing = state.cart.find(item => item.product.id === action.payload.id);
      if (existing) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item.product.id === action.payload.id
              ? { ...item, quantity: item.quantity + 1 }
              : item
          ),
        };
      }
      return { ...state, cart: [...state.cart, { product: action.payload, quantity: 1 }] };
    }
    case 'REMOVE_FROM_CART':
      return { ...state, cart: state.cart.filter(item => item.product.id !== action.payload) };
    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.product.id === action.payload.productId
            ? { ...item, quantity: action.payload.quantity }
            : item
        ),
      };
    case 'CLEAR_CART':
      return { ...state, cart: [] };
    case 'PLACE_ORDER':
      return { ...state, orders: [action.payload, ...state.orders], cart: [] };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(o =>
          o.id === action.payload.orderId ? { ...o, status: action.payload.status } : o
        ),
      };
    case 'ADD_PRODUCT':
      return { ...state, products: [action.payload, ...state.products] };
    case 'UPDATE_PRODUCT':
      return {
        ...state,
        products: state.products.map(p => (p.id === action.payload.id ? action.payload : p)),
      };
    case 'DELETE_PRODUCT':
      return { ...state, products: state.products.filter(p => p.id !== action.payload) };
    default:
      return state;
  }
}

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, initialState);
  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

export function useCart() {
  const { state, dispatch } = useApp();
  const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
  const subtotal = state.cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const shipping = subtotal >= 500000 ? 0 : 30000;
  const total = subtotal + shipping;
  return { cart: state.cart, totalItems, subtotal, shipping, total, dispatch };
}

export function useAuth() {
  const { state, dispatch } = useApp();
  const login = (email: string, password: string): boolean => {
    if (email === 'admin@sportzone.vn' && password === 'admin123') {
      dispatch({ type: 'LOGIN', payload: { id: 'admin', name: 'Quản trị viên', email, role: 'admin', phone: '0900 000 000', address: 'SportZone HQ', joinDate: '2023-01-01' } });
      return true;
    }
    if (email === 'user@example.com' && password === 'user123') {
      dispatch({ type: 'LOGIN', payload: { id: 'u_demo', name: 'Nguyễn Demo', email, role: 'user', phone: '0909 123 456', address: '100 Nguyễn Trãi, Q.1, TP.HCM', joinDate: '2024-06-01' } });
      return true;
    }
    return false;
  };
  const register = (name: string, email: string) => {
    dispatch({ type: 'LOGIN', payload: { id: `u_${Date.now()}`, name, email, role: 'user', phone: '', address: '', joinDate: new Date().toISOString().split('T')[0] } });
  };
  const logout = () => dispatch({ type: 'LOGOUT' });
  return { user: state.user, isAuthenticated: !!state.user, login, register, logout };
}
